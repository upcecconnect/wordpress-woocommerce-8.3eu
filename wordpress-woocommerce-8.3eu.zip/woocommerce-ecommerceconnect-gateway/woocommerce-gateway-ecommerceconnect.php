<?php
/**
 * Plugin Name: eCommerceConnect Gateway
 * Plugin URI: https://ecconnect.upc.ua
 * Description: UPC WooCommerce plugin enables you to easily accept payments through your Woocommerce store
 * Author: upc.ua
 * Author URI: https://upc.ua
 * Version: 1.0.0
 * Requires at least: 6.3
 * Tested up to: 6.4
 * WC requires at least: 8.4
 * WC tested up to: 8.6
 * Requires PHP: 7.4
 * PHP tested up to: 8.3
 */

defined( 'ABSPATH' ) || exit;

define( 'WC_GATEWAY_ECOMMERCECONNECT_VERSION', '1.0.0' ); 
define( 'WC_GATEWAY_ECOMMERCECONNECT_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );
define( 'WC_GATEWAY_ECOMMERCECONNECT_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

function woocommerce_ecommerceconnect_init() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	require_once plugin_basename( 'includes/class-wc-gateway-ecommerceconnect.php' );
	require_once plugin_basename( 'includes/class-wc-gateway-ecommerceconnect-privacy.php' );
	load_plugin_textdomain( 'woocommerce-gateway-ecommerceconnect', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );
	add_filter( 'woocommerce_payment_gateways', 'woocommerce_ecommerceconnect_add_gateway' );
}
add_action( 'plugins_loaded', 'woocommerce_ecommerceconnect_init', 0 );

function woocommerce_ecommerceconnect_plugin_links( $links ) {
	$settings_url = add_query_arg(
		array(
			'page'    => 'wc-settings',
			'tab'     => 'checkout',
			'section' => 'wc_gateway_ecommerceconnect',
		),
		admin_url( 'admin.php' )
	);

	$plugin_links = array(
		'<a href="' . esc_url( $settings_url ) . '">' . esc_html__( 'Settings', 'woocommerce-gateway-ecommerceconnect' ) . '</a>',
		'<a href="https://ecconnect.upc.ua">' . esc_html__( 'Support', 'woocommerce-gateway-ecommerceconnect' ) . '</a>'		
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'woocommerce_ecommerceconnect_plugin_links' );

function woocommerce_ecommerceconnect_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_eCommerceConnect';
	return $methods;
}

add_action( 'woocommerce_blocks_loaded', 'woocommerce_ecommerceconnect_woocommerce_blocks_support' );

function woocommerce_ecommerceconnect_woocommerce_blocks_support() {
	if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
		require_once WC_GATEWAY_ECOMMERCECONNECT_PATH . '/includes/class-wc-gateway-ecommerceconnect-blocks-support.php';
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function ( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
				$payment_method_registry->register( new WC_eCommerceConnect_Blocks_Support() );
			}
		);
	}
}

function woocommerce_ecommerceconnect_declare_feature_compatibility() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			__FILE__
		);

		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'product_block_editor',
			__FILE__
		);
	}
}
add_action( 'before_woocommerce_init', 'woocommerce_ecommerceconnect_declare_feature_compatibility' );

function woocommerce_ecommerceconnect_missing_wc_notice() {
	if ( class_exists( 'WooCommerce' ) ) {
		return;
	}

	echo '<div class="error"><p><strong>';
	printf(
		esc_html__( 'WooCommerce eCommerceConnect Gateway requires WooCommerce to be installed and active. You can download %s here.', 'woocommerce-gateway-ecommerceconnect' ),
		'<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>'
	);
	echo '</strong></p></div>';
}
add_action( 'admin_notices', 'woocommerce_ecommerceconnect_missing_wc_notice' );
